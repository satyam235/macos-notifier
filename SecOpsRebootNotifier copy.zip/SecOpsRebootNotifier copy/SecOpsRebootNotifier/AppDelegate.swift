import AppKit

class AppDelegate: NSObject, NSApplicationDelegate {
    private var panelController: PanelController?
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        let arguments = CommandLine.arguments.dropFirst()
        let config = AppConfiguration.parse(from: Array(arguments))
        
        let state = RebootState(initialSeconds: config.countdownSeconds,
                                allowedDelayOptions: config.delayOptions,
                                maxTotalDelay: config.maxTotalDelay)
        
        let logger = ActionLogger(stateFilePath: config.stateFilePath,
                                  historyLogPath: config.historyFilePath)
        
        panelController = PanelController(state: state, logger: logger)
        panelController?.show()
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}

// MARK: - Configuration
struct AppConfiguration {
    let countdownSeconds: Int
    let delayOptions: [Int]
    let stateFilePath: String
    let historyFilePath: String
    let maxTotalDelay: Int?
    
    static func parse(from args: [String]) -> AppConfiguration {
        var countdown = 300
        var delays: [Int] = [3600, 7200, 21600]
        var statePath = "/tmp/reboot_state.json"
        var historyPath = "/tmp/reboot_action_history.log"
        var maxDelay: Int?
        
        var iterator = args.makeIterator()
        while let arg = iterator.next() {
            switch arg {
            case "--countdown":
                if let v = iterator.next(), let intV = Int(v) {
                    countdown = intV
                }
            case "--delays":
                if let v = iterator.next() {
                    let parts = v.split(separator: ",").compactMap { Int($0.trimmingCharacters(in: .whitespaces)) }
                    if !parts.isEmpty { delays = parts }
                }
            case "--state-file":
                if let v = iterator.next() { statePath = v }
            case "--log-file":
                if let v = iterator.next() { historyPath = v }
            case "--max-total-delay":
                if let v = iterator.next(), let intV = Int(v) { maxDelay = intV }
            default:
                break
            }
        }
        
        return AppConfiguration(countdownSeconds: countdown,
                                delayOptions: delays.sorted(),
                                stateFilePath: statePath,
                                historyFilePath: historyPath,
                                maxTotalDelay: maxDelay)
    }
}